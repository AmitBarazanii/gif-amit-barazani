package com.example.gif;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    ImageView donkey, play, pause;
    AudioManager am;
    MediaPlayer mp;
    int max;
    boolean IsStopped;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        play = findViewById(R.id.play);
        pause = findViewById(R.id.pause);
        mp = MediaPlayer.create(this, R.raw.song);
        donkey = findViewById(R.id.don_key_kong);
        GifPlayer gifPlayer = new GifPlayer(donkey);
        gifPlayer.start();
        IsStopped = false;
        mp.start();
        am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        am.setStreamVolume(AudioManager.STREAM_MUSIC,max/2,0);
        pause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mp.pause();
                gifPlayer.StopTheAnim();
            }
        });
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mp.start();
                gifPlayer.ContinueTheAnim();
            }
        });
    }
    protected void onPause(){
        super.onPause();
        mp.release();
    }
    class GifPlayer extends Thread {
        private ImageView donkey;

        public GifPlayer(ImageView donkey){
            this.donkey = donkey;
        }
        public void run()
        {
            for (int i = 0; i < 12; i++){
                if (!IsStopped) {
                    try {
                        Thread.sleep(40);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    int ImageKey = getResources().getIdentifier("p" + i, "drawable", getPackageName());
                    donkey.setImageResource(ImageKey);
                }
                if (i == 11) i = 0;
            }
        }
        public void StopTheAnim(){
            IsStopped = true;
        }
        public void ContinueTheAnim(){
            IsStopped = false;
        }
    }
}